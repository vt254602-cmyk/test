## Goal
Replace the 4-question seed with the full 24-question Product Test Demo from the uploaded PDF. Keep changes minimal.

## Question breakdown (from PDF)
- **MCQ single answer (8)**: Q1–Q5, Q8, Q9, Q10 — answers: 1C, 2C, 3B, 4B, 5C, 8B, 9B, 10A
- **MCQ multi answer (2)**: Q6 → A,C,D · Q7 → B,D
- **Written (14)**: Q11–Q24 (each with the prompt text + a brief "sample direction" pulled from the PDF's answer key where present; short placeholder where not)

## Code changes
1. **`src/lib/quiz-store.ts`**
   - Extend `McqQuestion.answer` to `string | string[]` (multi-select support).
   - Replace `seed` with all 24 questions verbatim from the PDF.

2. **`src/components/exam/ExamSimulator.tsx`**
   - For MCQ: if `answer` is an array, render checkboxes (toggle selection stored as sorted joined string `"A|B"`), else current radio behavior.
   - Grading: compare normalized sets.
   - Review screen: show array answers joined by `, `.

3. **`src/components/exam/QuestionEditor.tsx`**
   - Add an "Allow multiple correct" checkbox; when on, the correct-answer picker becomes multi-select. (Small additive change; existing single-answer flow unchanged by default.)

No new packages. In-memory only. Route structure unchanged.

## Out of scope
- Per-question time limits, scoring weights, or partial credit on multi-select (treat as all-or-nothing match).
- Importing PDFs at runtime.
